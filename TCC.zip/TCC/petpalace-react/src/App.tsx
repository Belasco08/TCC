import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Home from "./pages/Home";
import Servicos from "./pages/Servicos";
import ServicosDetalhes from "./pages/ServicosDetalhes";
import Hoteis from "./pages/Hoteis";
import HotelDetalhes from "./pages/HotelDetalhes";
import Login from "./pages/Login";
import Cadastrar from "./pages/Cadastrar";
import CadastrarHotel from "./pages/CadastrarHotel";
import Perfil from "./pages/Perfil";


import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./routes/ProtectedRoute";

const App: React.FC = () => {
  return (
    <AuthProvider>
      
      <BrowserRouter>
        <Routes>
         
          <Route path="/" element={<Home />} />
          <Route path="/servicos" element={<Servicos />} />
          <Route path="/servicos/:id" element={<ServicosDetalhes />} />
          <Route path="/hoteis" element={<Hoteis />} />
          <Route path="/hoteis/:id" element={<HotelDetalhes />} />
          <Route path="/login" element={<Login />} />
          <Route path="/cadastrar" element={<Cadastrar />} />

          
          <Route
            path="/cadastrarhotel"
            element={
              <ProtectedRoute>
                <CadastrarHotel />
              </ProtectedRoute>
            }
          />
          <Route
            path="/perfil"
            element={
              <ProtectedRoute>
                <Perfil />
              </ProtectedRoute>
            }
          />

          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;
