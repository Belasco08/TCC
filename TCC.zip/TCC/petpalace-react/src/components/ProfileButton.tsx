// src/components/ProfileButton.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "../styles/ProfileButton.css";

const ProfileButton: React.FC = () => {
  const { user: ctxUser, logout } = useAuth();


  const stored = typeof window !== "undefined" ? localStorage.getItem("pp_user") : null;
  const parsed = stored ? JSON.parse(stored) : null;

  const user = ctxUser || parsed;

  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  if (!user) return null;

  const avatar =
    user.foto ||
    user.fotoPerfil ||
    "https://cdn-icons-png.flaticon.com/512/149/149071.png";

  const handlePerfil = () => {
    setOpen(false);
    navigate("/perfil");
  };

  const handleLogout = () => {
    logout();
    localStorage.removeItem("pp_user");
    window.location.reload();
  };

  return (
    <div className="profile-btn-container" style={{ position: "relative" }}>
      <img
        src={avatar}
        alt={user.nome || "Usuário"}
        className="profile-btn-avatar"
        onClick={() => setOpen(s => !s)}
      />
      <span style={{ color: "#fff", marginLeft: 8, fontWeight: 600 }}>
        {user.nome || "Usuário"}
      </span>

      {open && (
        <div className="profile-btn-menu" style={{ right: 0 }}>
          <button onClick={handlePerfil}>Meu Perfil</button>
          <button className="logout" onClick={handleLogout}>
            Sair
          </button>
        </div>
      )}
    </div>
  );
};

export default ProfileButton;
