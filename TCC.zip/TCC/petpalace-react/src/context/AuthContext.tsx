import React, { createContext, useContext, useState, useEffect } from "react";
import Cookies from "js-cookie";
import api from "../service/api";

interface User {
  id: number;
  nome: string;
  email: string;
  foto?: string | null;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (userData: User, jwtToken: string) => void;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  login: () => {},
  logout: () => {},
  loading: true,
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
 
    const cookieUser = Cookies.get("user");
    const cookieToken = Cookies.get("token");

    
    const localUser = localStorage.getItem("pp_user");

    if (cookieUser && cookieToken) {
      const parsed = JSON.parse(cookieUser);
      setUser(parsed);
      setToken(cookieToken);
      api.defaults.headers.common["Authorization"] = `Bearer ${cookieToken}`;
    } 
    else if (localUser) {
      const parsed = JSON.parse(localUser);
      setUser(parsed);
      setToken(null); 
    }

    setLoading(false);
  }, []);

  const login = (userData: User, jwtToken: string) => {
    setUser(userData);
    setToken(jwtToken);

    Cookies.set("user", JSON.stringify(userData), { expires: 7 });
    Cookies.set("token", jwtToken, { expires: 7 });

    localStorage.setItem("pp_user", JSON.stringify(userData));

    api.defaults.headers.common["Authorization"] = `Bearer ${jwtToken}`;
  };

  const logout = () => {
    setUser(null);
    setToken(null);

    Cookies.remove("user");
    Cookies.remove("token");

    localStorage.removeItem("pp_user");

    delete api.defaults.headers.common["Authorization"];
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
