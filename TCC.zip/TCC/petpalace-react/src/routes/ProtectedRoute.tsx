import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

interface ProtectedRouteProps {
  children: JSX.Element;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { user, loading } = useAuth();

  // Enquanto o AuthContext está carregando (cookies/localStorage)
  if (loading) return null;

  // Fallback: usuário salvo no localStorage (pp_user)
  const stored = localStorage.getItem("pp_user");
  const localUser = stored ? JSON.parse(stored) : null;

  // Se não tem usuário no contexto e nem no localStorage → volta pro login
  if (!user && !localUser) {
    return <Navigate to="/login" replace />;
  }

  // Se tem usuário -> libera a rota
  return children;
};

export default ProtectedRoute;
