import React, { useEffect, useState } from "react";
import "../styles/Perfil.css";
import userIcon from "../assets/img/user-icon.png";
import api from "../service/api";
import petsImage from "../assets/img/gatodeitado.webp";
import Navbar from "../components/Navbar"; 
const Perfil: React.FC = () => {
  const [userData, setUserData] = useState<{ nome: string; email: string } | null>(null);

  useEffect(() => {

    const storedUser = localStorage.getItem("pp_user");
    if (storedUser) {
      setUserData(JSON.parse(storedUser));
    } else {
      setUserData({ nome: "Usuário PetPalace", email: "usuario@petpalace.com" });
    }
  }, []);

  const handleEdit = () => {
    alert("Função de edição em desenvolvimento ");
  };

  return (
    <div className="perfil-page">

      {}
      <Navbar />

      <div className="perfil-container">
        <div className="perfil-header">
          <img src={userIcon} alt="Usuário" className="perfil-foto" />
          <div>
            <h2>{userData?.nome}</h2>
            <p>{userData?.email}</p>
          </div>
        </div>

        <div className="perfil-card">
          <h3>Informações da Conta</h3>
          <p><strong>Nome:</strong> {userData?.nome}</p>
          <p><strong>E-mail:</strong> {userData?.email}</p>
         
        </div>

        <div className="perfil-card">
          <h3>Sobre nós</h3>
          <p>O PetPalace é uma host que conecta donos de pets a hotéis e serviços especializados para animais.
             Nossa missão é facilitar a hospedagem e os cuidados com os pets, oferecendo opções seguras, confiáveis e confortáveis. 
             No PetPalace, donos podem encontrar facilmente lugares que garantam bem-estar,
             atenção e carinho para seus animais, tornando a experiência de cuidar deles mais prática e tranquila.</p>
        </div>

      </div>
    </div>
  );
};

export default Perfil;
