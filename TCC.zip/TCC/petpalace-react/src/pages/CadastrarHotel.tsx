import React, { useState, DragEvent, ChangeEvent } from "react";
import Navbar from "../components/Navbar";
import "../styles/CadastrarHotel.css";
import { useNavigate } from "react-router-dom";

const CadastrarHotel: React.FC = () => {
  const navigate = useNavigate();

  const [tipoCadastro, setTipoCadastro] = useState<"hotel" | "servico">(
    "hotel"
  );

  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    preco: "",
    cidade: "",
    estado: "",
    enderecoTexto: "",
    telefone: "",
    email: "",
    aceita_gatos: false,
    aceita_caes: false,
  });

  const [imagens, setImagens] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const [dragOver, setDragOver] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;
    setFormData({
      ...formData,
      [name]:
        type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    });
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const newPreviews = files.map((file) => URL.createObjectURL(file));
      setImagens((prev) => [...prev, ...files]);
      setPreviewUrls((prev) => [...prev, ...newPreviews]);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    const newPreviews = files.map((file) => URL.createObjectURL(file));
    setImagens((prev) => [...prev, ...files]);
    setPreviewUrls((prev) => [...prev, ...newPreviews]);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => setDragOver(false);

  const handleRemoveImage = (index: number) => {
    setPreviewUrls((prev) => prev.filter((_, i) => i !== index));
    setImagens((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const url =
      tipoCadastro === "hotel"
        ? "http://localhost:8080/unidades"
        : "http://localhost:8080/servicos";

    
    if (tipoCadastro === "servico") {
      const dadosServico = {
        nome: formData.nome,
        descricao: formData.descricao,
        preco: formData.preco,
        telefone: formData.telefone,
        email: formData.email,
      };

      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dadosServico),
        });

        if (resp.ok) {
          alert("Serviço cadastrado com sucesso!");
          navigate("/");
        } else {
          alert("Erro ao cadastrar serviço.");
        }
      } catch (err) {
        alert("Erro de conexão.");
      }

      return;
    }

    
    const data = new FormData();
    for (const key in formData) {
      data.append(key, (formData as any)[key]);
    }

    imagens.forEach((img) => data.append("fotos", img));

    try {
      const resp = await fetch(url, { method: "POST", body: data });

      if (resp.ok) {
        alert("Hotel cadastrado com sucesso!");
        navigate("/");
      } else {
        alert("Erro ao cadastrar hotel.");
      }
    } catch (err) {
      alert("Erro de conexão.");
    }
  };

  return (
    <>
      <Navbar />

      <div className="cadastrarhotel-page">
        <section className="cadastrarhotel-section">
          <div className="cadastrarhotel-form-container">
            <div className="switch-cadastro">
              <button
                className={tipoCadastro === "hotel" ? "active" : ""}
                onClick={() => setTipoCadastro("hotel")}
              >
                Cadastrar Hotel
              </button>

              <button
                className={tipoCadastro === "servico" ? "active" : ""}
                onClick={() => setTipoCadastro("servico")}
              >
                Cadastrar Serviço
              </button>
            </div>

            <h1>
              {tipoCadastro === "hotel"
                ? "Cadastrar Hotel"
                : "Cadastrar Serviço"}
            </h1>

            <form onSubmit={handleSubmit} className="cadastrarhotel-form">
              <div className="cadastrarhotel-form-grid">
                <input
                  type="text"
                  name="nome"
                  placeholder={
                    tipoCadastro === "hotel"
                      ? "Nome do Hotel"
                      : "Nome do Serviço"
                  }
                  value={formData.nome}
                  onChange={handleChange}
                  required
                />

                <textarea
                  name="descricao"
                  placeholder="Descrição"
                  value={formData.descricao}
                  onChange={handleChange}
                />

                <input
                  type="number"
                  name="preco"
                  placeholder={
                    tipoCadastro === "hotel"
                      ? "Preço por diária"
                      : "Preço do serviço"
                  }
                  value={formData.preco}
                  onChange={handleChange}
                />

                {}
                {tipoCadastro === "hotel" && (
                  <>
                    <input
                      type="text"
                      name="cidade"
                      placeholder="Cidade"
                      value={formData.cidade}
                      onChange={handleChange}
                    />

                    <input
                      type="text"
                      name="estado"
                      placeholder="Estado"
                      value={formData.estado}
                      onChange={handleChange}
                    />

                    <input
                      type="text"
                      name="enderecoTexto"
                      placeholder="Endereço"
                      value={formData.enderecoTexto}
                      onChange={handleChange}
                    />

                    <label>
                      <input
                        type="checkbox"
                        name="aceita_caes"
                        checked={formData.aceita_caes}
                        onChange={handleChange}
                      />
                      Aceita cães
                    </label>

                    <label>
                      <input
                        type="checkbox"
                        name="aceita_gatos"
                        checked={formData.aceita_gatos}
                        onChange={handleChange}
                      />
                      Aceita gatos
                    </label>
                  </>
                )}

                <input
                  type="text"
                  name="telefone"
                  placeholder="Telefone"
                  value={formData.telefone}
                  onChange={handleChange}
                />

                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>

              {}
              {tipoCadastro === "hotel" && (
                <div
                  className={`upload-area ${dragOver ? "dragover" : ""}`}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  <p>Arraste imagens ou clique para selecionar</p>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleFileChange}
                  />

                  <div className="preview-grid">
                    {previewUrls.map((url, index) => (
                      <div key={index} className="preview-wrapper">
                        <img src={url} className="preview-image" />
                        <button
                          type="button"
                          className="remove-image-btn"
                          onClick={() => handleRemoveImage(index)}
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button type="submit" className="cadastrarhotel-btn-cadastrar">
                Cadastrar
              </button>
            </form>
          </div>
        </section>
      </div>
    </>
  );
};

export default CadastrarHotel;
