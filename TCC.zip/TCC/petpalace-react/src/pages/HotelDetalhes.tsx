// src/pages/HotelDetalhes.tsx
import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../service/api";
import Navbar from "../components/Navbar";
import Slider from "react-slick";
import "../styles/HotelDetalhes.css";

interface Unidade {
  id: number;
  nome: string;
  descricao?: string;
  cidade?: string;
  estado?: string;
  preco?: number;
  fotos?: string[];
  telefone?: string;
  email?: string;
}

const HotelDetalhes: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [unidade, setUnidade] = useState<Unidade | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) {
      setError("ID do hotel não fornecido.");
      setLoading(false);
      return;
    }

    const fetch = async () => {
      try {
        const resp = await api.get(`/unidades/${id}`);
        if (!resp.data) {
          setError("Hotel não encontrado.");
        } else {
          setUnidade(resp.data);
        }
      } catch (err) {
        console.error(err);
        setError("Erro ao carregar o hotel.");
      } finally {
        setLoading(false);
      }
    };

    fetch();
  }, [id]);

  if (loading) return <p>Carregando...</p>;
  if (error) return <p>{error}</p>;
  if (!unidade) return <p>Hotel não encontrado.</p>;

  const whatsapp = unidade.telefone ? unidade.telefone.replace(/\D/g, "") : null;
  const message = encodeURIComponent(`Olá! Tenho interesse na hospedagem no ${unidade.nome}.`);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
  };

  // Função para fallback de imagem
  const handleImgError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = `https://placedog.net/900/500?id=${unidade?.id}`;
  };

  return (
    <>
      <Navbar />

      <section className="hotel-detalhes">
        <div className="galeria">
          <Slider {...settings}>
            {unidade.fotos?.length ? (
              unidade.fotos.map((f, idx) => (
                <div key={idx}>
                  <img
                    src={f}
                    alt={`${unidade.nome} ${idx}`}
                    onError={handleImgError}
                  />
                </div>
              ))
            ) : (
              <div>
                <img
                  src={`https://placedog.net/900/500?id=${unidade.id}`}
                  alt="Imagem fallback"
                  onError={handleImgError}
                />
              </div>
            )}
          </Slider>
        </div>

        <div className="detalhes">
          <h2>{unidade.nome}</h2>
          <p className="cidade">
            {unidade.cidade} {unidade.estado ? `- ${unidade.estado}` : ""}
          </p>
          <p className="descricao">{unidade.descricao}</p>
          {unidade.preco && <p className="preco">A partir de R$ {unidade.preco}</p>}

          <div className="anfitriao-card">
            <h4>Contato do anfitrião</h4>
            {unidade.telefone && <p>Telefone: {unidade.telefone}</p>}

            {whatsapp && (
              <a
                className="btn"
                href={`https://wa.me/${whatsapp}?text=${message}`}
                target="_blank"
              >
                Falar pelo WhatsApp
              </a>
            )}

            {unidade.email && <p>E-mail: {unidade.email}</p>}
          </div>

          <Link to="/hoteis" className="btn outline">
            Voltar à lista
          </Link>
        </div>
      </section>
    </>
  );
};

export default HotelDetalhes;
