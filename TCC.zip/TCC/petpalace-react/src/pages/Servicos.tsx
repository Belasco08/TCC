import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../service/api";
import Navbar from "../components/Navbar";
import "../styles/Servicos.css";

interface Servico {
  id: number;
  nome: string;
  descricao: string;
  cidade: string;
  estado: string;
  preco: number;
  telefone?: string;
  email?: string;
}

const Servicos: React.FC = () => {
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const carregarServicos = async () => {
      try {
        setLoading(true);
        const response = await api.get("/servicos");
        setServicos(response.data);
      } catch (err) {
        console.error("Erro ao carregar serviços:", err);
      } finally {
        setLoading(false);
      }
    };
    carregarServicos();
  }, []);

  const filtrados = servicos.filter((s) => {
    const t = search.toLowerCase();
    return (
      s.nome.toLowerCase().includes(t) ||
      s.cidade.toLowerCase().includes(t) ||
      s.estado.toLowerCase().includes(t)
    );
  });

  return (
    <>
      <Navbar />

      <section className="servicos-page">
        <div className="search-bar">
          <input
            type="text"
            placeholder="Pesquisar serviço, cidade ou estado..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="servicos-list">
          {loading && <p>Carregando serviços...</p>}
          {!loading && filtrados.length === 0 && <p>Nenhum serviço encontrado.</p>}

          {filtrados.map((s) => (
            <div className="servico-card" key={s.id}>
              <div className="servico-card-body">
                <h3>{s.nome}</h3>

                <p className="cidade">
                  {s.cidade} - {s.estado}
                </p>

                <p className="preco">A partir de R$ {s.preco}</p>

                <div className="acoes">
                  <Link to={`/servicos/${s.id}`} className="btn">
                    Ver detalhes
                  </Link>

                  {s.telefone && (
                    <a
                      className="btn outline"
                      href={`tel:${s.telefone.replace(/\D/g, "")}`}
                    >
                      Ligar
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Servicos;
