import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../service/api";
import Navbar from "../components/Navbar";
import "../styles/ServicosDetalhes.css";

interface Servico {
  id: number;
  nome: string;
  descricao: string;
  preco: number;
  cidade: string;
  estado: string;
  telefone?: string;
  email?: string;
}

const ServicosDetalhes: React.FC = () => {
  const { id } = useParams();
  const [servico, setServico] = useState<Servico | null>(null);

  useEffect(() => {
    if (!id) return;

    api
      .get(`/servicos/${id}`)
      .then((res) => {
        const data = res.data;

        if (!data.telefone) data.telefone = "(14) 99999-9999";
        if (!data.email) data.email = "contato@petpalace.com";

        setServico(data);
      })
      .catch((err) => console.error("Erro ao carregar serviço:", err));
  }, [id]);

  if (!servico) return <div>Carregando...</div>;

  const telefoneLimpo = servico.telefone.replace(/\D/g, "");

  return (
    <>
      <Navbar />

      <div className="servico-detalhes">
        <div className="detalhes">
          <h2>{servico.nome}</h2>

          <p className="cidade">
            {servico.cidade} - {servico.estado}
          </p>

          <p className="descricao">{servico.descricao}</p>

          <p className="preco">R$ {servico.preco.toFixed(2)}</p>

          <div className="anfitriao-card">
            <h3>Entre em contato</h3>

            <div className="contatos-servico">
              <a
                className="btn"
                href={`https://wa.me/55${telefoneLimpo}`}
                target="_blank"
              >
                WhatsApp
              </a>

              <a className="btn outline" href={`tel:${telefoneLimpo}`}>
                Ligar
              </a>

              <a className="btn outline" href={`mailto:${servico.email}`}>
                E-mail
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ServicosDetalhes;