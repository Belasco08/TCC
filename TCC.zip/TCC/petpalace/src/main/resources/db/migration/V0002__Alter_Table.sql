ALTER TABLE tb_estado
    ADD CONSTRAINT fk_estado_pais FOREIGN KEY (pais_id) REFERENCES tb_pais(id);

ALTER TABLE tb_cidade
    ADD CONSTRAINT fk_cidade_estado FOREIGN KEY (estado_id) REFERENCES tb_estado(id);

ALTER TABLE tb_endereco
    ADD CONSTRAINT fk_endereco_cidade FOREIGN KEY (cidade_id) REFERENCES tb_cidade(id),
    ADD CONSTRAINT fk_endereco_estado FOREIGN KEY (estado_id) REFERENCES tb_estado(id),
    ADD CONSTRAINT fk_endereco_pais   FOREIGN KEY (pais_id) REFERENCES tb_pais(id);

ALTER TABLE tb_raca
    ADD CONSTRAINT fk_raca_especie FOREIGN KEY (especie_id) REFERENCES tb_especie(id);

ALTER TABLE tb_usuario
    ADD CONSTRAINT fk_usuario_tipoUsuario FOREIGN KEY (tipoUsuario_id) REFERENCES tb_tipoUsuario(id),
    ADD CONSTRAINT fk_usuario_endereco FOREIGN KEY (endereco_id) REFERENCES tb_endereco(id);

ALTER TABLE tb_unidade
    ADD CONSTRAINT fk_unidade_mapa FOREIGN KEY (mapa_id) REFERENCES tb_mapa(id),
    ADD CONSTRAINT fk_unidade_tipo FOREIGN KEY (tipoUnidade_id) REFERENCES tb_tipoUnidade(id),
    ADD CONSTRAINT fk_unidade_endereco FOREIGN KEY (endereco_id) REFERENCES tb_endereco(id),
    ADD CONSTRAINT fk_unidade_servico FOREIGN KEY (servico_id) REFERENCES tb_servico(id);

ALTER TABLE tb_unidadeEspecie
    ADD CONSTRAINT fk_unidadeEspecie_unidade FOREIGN KEY (unidade_id) REFERENCES tb_unidade(id),
    ADD CONSTRAINT fk_unidadeEspecie_especie FOREIGN KEY (especie_id) REFERENCES tb_especie(id);

ALTER TABLE tb_animal
    ADD CONSTRAINT fk_animal_porte FOREIGN KEY (porte_id) REFERENCES tb_porte(id),
    ADD CONSTRAINT fk_animal_especie FOREIGN KEY (especie_id) REFERENCES tb_especie(id),
    ADD CONSTRAINT fk_animal_raca FOREIGN KEY (raca_id) REFERENCES tb_raca(id),
    ADD CONSTRAINT fk_animal_usuario FOREIGN KEY (usuario_id) REFERENCES tb_usuario(id);

ALTER TABLE tb_agendamento
    ADD CONSTRAINT fk_agendamento_unidade FOREIGN KEY (unidade_id) REFERENCES tb_unidade(id),
    ADD CONSTRAINT fk_agendamento_animal FOREIGN KEY (animal_id) REFERENCES tb_animal(id),
    ADD CONSTRAINT fk_agendamento_servico FOREIGN KEY (servico_id) REFERENCES tb_servico(id),
    ADD CONSTRAINT fk_agendamento_usuario FOREIGN KEY (usuario_id) REFERENCES tb_usuario(id);

ALTER TABLE tb_anuncios
    ADD CONSTRAINT fk_anuncios_endereco FOREIGN KEY (endereco_id) REFERENCES tb_endereco(id),
    ADD CONSTRAINT fk_anuncios_mapa FOREIGN KEY (mapa_id) REFERENCES tb_mapa(id),
    ADD CONSTRAINT fk_anuncios_unidade FOREIGN KEY (unidade_id) REFERENCES tb_unidade(id);

ALTER TABLE tb_pais ADD COLUMN codigo_inter VARCHAR(10);
