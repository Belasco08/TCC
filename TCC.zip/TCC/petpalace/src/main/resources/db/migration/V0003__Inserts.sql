INSERT INTO tb_tipo_unidade (id, descricao)
VALUES
    (1, 'Hotel Pet'),
    (2, 'Creche Pet'),
    (3, 'Pet Sitter');

INSERT INTO tb_servico (id, nome, descricao, telefone, preco, cidade, estado)
VALUES
    (1, 'Hospedagem completa', 'Hospedagem com cuidados 24h', '(14) 99999-1111', 120.00, 'Bauru', 'SP'),
    (2, 'Creche diurna', 'Creche com acompanhamento', '(11) 97777-2222', 80.00, 'São Paulo', 'SP'),
    (3, 'Passeio', 'Passeios diários com o pet', '(19) 98888-3333', 40.00, 'Campinas', 'SP');



INSERT INTO tb_mapa (id, latitude, longitude)
VALUES
    (1, -23.5505, -46.6333),   -- São Paulo
    (2, -22.9068, -43.1729),   -- Rio de Janeiro
    (3, -19.9167, -43.9345);   -- Belo Horizonte

INSERT INTO tb_endereco (id, rua, numero, cep)
VALUES
    (1, 'Rua Exemplo', '123', '00000-000'),
    (2, 'Av. Teste', '456', '11111-111'),
    (3, 'Travessa Modelo', '789', '22222-222');

INSERT INTO tb_unidade (
    id, nome, descricao, aceita_gatos, aceita_caes,
    cidade, estado, telefone, email, endereco_texto,
    preco, mapa_id, tipoUnidade_id, endereco_id, servico_id
)
VALUES
    (1, 'Pet Hotel São Paulo', 'Hotel Premium para pets', TRUE, TRUE,
     'São Paulo', 'SP', '(11) 99999-0000', 'sppethotel@teste.com', 'Rua Exemplo 123, São Paulo',
     120.00, 1, 1, 1, 1),

    (2, 'Creche Pet Rio', 'Creche completa com área externa', TRUE, TRUE,
     'Rio de Janeiro', 'RJ', '(21) 99999-1111', 'riocreche@teste.com', 'Av. Teste 456, Rio',
     80.00, 2, 2, 2, 2),

    (3, 'Pet Hotel BH', 'Hospedagem aconchegante 24h', TRUE, FALSE,
     'Belo Horizonte', 'MG', '(31) 99999-2222', 'bhhotel@teste.com', 'Travessa Modelo 789, BH',
     95.00, 3, 1, 3, 1);
