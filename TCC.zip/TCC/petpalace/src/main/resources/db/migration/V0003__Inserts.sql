
INSERT INTO tb_pais (nome, sigla, codigoInter) VALUES
('Brasil', 'BR', '+55'),
('Estados Unidos', 'US', '+1');

INSERT INTO tb_estado (nome, uf, pais_id) VALUES
('São Paulo', 'SP', 1),
('Rio de Janeiro', 'RJ', 1),
('California', 'CA', 2);

INSERT INTO tb_cidade (nome, cep, estado_id) VALUES
('Bauru', '17000-000', 1),
('Rio de Janeiro', '20000-000', 2),
('Los Angeles', '90001', 3);

INSERT INTO tb_endereco (cep, rua, numero, complemento, bairro, latitude, longitude, cidade_id, estado_id, pais_id) VALUES
('17012-345', 'Rua das Flores', '100', 'Apto 12', 'Centro', -22.3145, -49.0606, 1, 1, 1),
('20031-050', 'Av. Atlântica', '500', NULL, 'Copacabana', -22.9710, -43.1825, 2, 2, 1),
('90001', 'Sunset Boulevard', '742', NULL, 'Hollywood', 34.0522, -118.2437, 3, 3, 2);

INSERT INTO tb_mapa (latitude, longitude) VALUES
(-22.3145, -49.0606),
(-22.9710, -43.1825),
(34.0522, -118.2437);

INSERT INTO tb_especie (nome) VALUES
('Cachorro'),
('Gato');

INSERT INTO tb_porte (descricao) VALUES
('Pequeno'),
('Médio'),
('Grande');

INSERT INTO tb_raca (nome, especie_id) VALUES
('Golden Retriever', 1),
('Poodle', 1),
('Persa', 2),
('Siamês', 2);

INSERT INTO tb_tipoUsuario (nome) VALUES
('Cliente'),
('Anfitrião'),
('Administrador');

INSERT INTO tb_tipoUnidade (descricao) VALUES
('Hotel para Pets'),
('Clínica Veterinária'),
('Petshop');

INSERT INTO tb_servico (nome, descricao, preco) VALUES
('Banho', 'Banho completo com produtos de qualidade', 50.00),
('Tosa', 'Tosa padrão ou estilizada', 70.00),
('Hospedagem', 'Diária de hospedagem para animais', 120.00);

INSERT INTO tb_usuario (nome, email, senha, telefone, foto_perfil, tipoUsuario_id, endereco_id) VALUES
('João Silva', 'joao@email.com', '123456', '14999999999', NULL, 1, 1),
('Maria Souza', 'maria@email.com', '654321', '21988888888', NULL, 2, 2),
('Admin', 'admin@petpalace.com', 'admin123', '000000000', NULL, 3, 3);

INSERT INTO tb_unidade (nome, descricao, aceita_gatos, aceita_caes, mapa_id, tipoUnidade_id, endereco_id, servico_id) VALUES
('Pet Hotel Bauru', 'Hotel confortável para cães e gatos', TRUE, TRUE, 1, 1, 1, 3),
('Clínica Vet Rio', 'Atendimento veterinário especializado', TRUE, TRUE, 2, 2, 2, 1),
('Petshop LA', 'Loja completa para pets', TRUE, TRUE, 3, 3, 3, 2);

INSERT INTO tb_unidadeEspecie (unidade_id, especie_id) VALUES
(1, 1), -- Hotel Bauru aceita Cachorro
(1, 2), -- Hotel Bauru aceita Gato
(2, 1), -- Clínica Rio aceita Cachorro
(3, 2); -- Petshop LA aceita Gato

INSERT INTO tb_animal (nome, idade, peso, observacoes, porte_id, especie_id, raca_id, usuario_id) VALUES
('Rex', 5, TRUE, 'Muito brincalhão', 2, 1, 1, 1),
('Luna', 2, FALSE, 'Gosta de carinho', 1, 2, 3, 1),
('Bob', 7, TRUE, 'Precisa de cuidados especiais', 3, 1, 2, 2);

INSERT INTO tb_agendamento (quantidade_animal, dataCheckin, dataCheckout, data, horario, unidade_id, animal_id, servico_id, usuario_id) VALUES
('1', '2025-09-20 14:00:00', '2025-09-22 10:00:00', '2025-09-20 00:00:00', '2025-09-20 14:00:00', 1, 1, 3, 1),
('1', '2025-09-21 09:00:00', '2025-09-21 11:00:00', '2025-09-21 00:00:00', '2025-09-21 09:00:00', 2, 3, 1, 2);

INSERT INTO tb_anuncios (titulo, descricao, preco_diaria, fotos, vagas_disponiveis, avaliacoes, endereco_id, mapa_id, data_criacao, unidade_id) VALUES
('Hotel para cães em Bauru', 'Ambiente seguro e confortável para seu pet', 120.00, 'foto1.jpg', 5, 'Ótimo lugar!', 1, 1, NOW(), 1),
('Clínica veterinária Rio', 'Consultas e procedimentos com especialistas', 200.00, 'foto2.jpg', 3, 'Atendimento excelente!', 2, 2, NOW(), 2),
('Petshop em LA', 'Tudo que seu pet precisa em um só lugar', 80.00, 'foto3.jpg', 10, 'Produtos variados', 3, 3, NOW(), 3);
