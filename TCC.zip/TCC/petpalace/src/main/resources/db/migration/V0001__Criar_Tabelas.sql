CREATE TABLE tb_pais (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    sigla VARCHAR(10),
    codigo_inter VARCHAR(10)
);

CREATE TABLE tb_estado (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    uf VARCHAR(10),
    pais_id BIGINT
);

CREATE TABLE tb_cidade (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    cep VARCHAR(20),
    estado_id BIGINT
);

CREATE TABLE tb_endereco (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    cep VARCHAR(20),
    rua VARCHAR(255),
    numero VARCHAR(50),
    complemento VARCHAR(255),
    bairro VARCHAR(255),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    cidade_id BIGINT,
    estado_id BIGINT,
    pais_id BIGINT
);

CREATE TABLE tb_mapa (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    latitude DOUBLE,
    longitude DOUBLE
);

CREATE TABLE tb_especie (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255)
);

CREATE TABLE tb_porte (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255)
);

CREATE TABLE tb_raca (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    especie_id BIGINT
);

CREATE TABLE tb_tipoUsuario (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255)
);

CREATE TABLE tb_tipo_unidade (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255)
);

CREATE TABLE tb_servico (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    descricao VARCHAR(255),
    telefone varchar (15),
    preco DECIMAL(10,2),
    cidade VARCHAR(100),
    estado VARCHAR(100)
);

CREATE TABLE tb_usuario (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    senha VARCHAR(255),
    telefone VARCHAR(20),
    foto_perfil VARCHAR(255),
    tipoUsuario_id BIGINT,
    endereco_id BIGINT
);

CREATE TABLE tb_foto_unidade (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_arquivo VARCHAR(255),
    content_type VARCHAR(255),
    tamanho BIGINT,
    dados LONGBLOB,
    unidade_id BIGINT
);

CREATE TABLE tb_unidade (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    descricao VARCHAR(255),
    aceita_gatos BOOLEAN,
    aceita_caes BOOLEAN,
    cidade VARCHAR(255),
    estado VARCHAR(255),
    telefone VARCHAR(255),
    email VARCHAR(255),
    endereco_texto VARCHAR(255),
    preco DOUBLE,
    mapa_id BIGINT,
    tipoUnidade_id BIGINT,
    endereco_id BIGINT,
    servico_id BIGINT
);

CREATE TABLE tb_unidadeEspecie (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    unidade_id BIGINT,
    especie_id BIGINT
);

CREATE TABLE tb_animal (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    idade INT,
    peso BOOLEAN,
    observacoes VARCHAR(255),
    porte_id BIGINT,
    especie_id BIGINT,
    raca_id BIGINT,
    usuario_id BIGINT
);

CREATE TABLE tb_agendamento (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    quantidade_animal VARCHAR(50),
    dataCheckin DATETIME,
    dataCheckout DATETIME,
    data DATETIME,
    horario DATETIME,
    unidade_id BIGINT,
    animal_id BIGINT,
    servico_id BIGINT,
    usuario_id BIGINT
);

CREATE TABLE tb_anuncios (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255),
    descricao VARCHAR(255),
    preco_diaria DECIMAL(10,2),
    fotos VARCHAR(255),
    vagas_disponiveis INT,
    avaliacoes VARCHAR(255),
    endereco_id BIGINT,
    mapa_id BIGINT,
    data_criacao DATETIME,
    unidade_id BIGINT
);
