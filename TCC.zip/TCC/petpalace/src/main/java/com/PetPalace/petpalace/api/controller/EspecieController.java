package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Animal;
import com.PetPalace.petpalace.domain.model.Especie;
import com.PetPalace.petpalace.domain.repository.EspecieRepository;
import com.PetPalace.petpalace.domain.service.EspecieService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/especies")
public class EspecieController {
    @Autowired
    private EspecieRepository especieRepository;
    @Autowired
    private EspecieService especieService;

    @GetMapping
    public List<Especie> listar(){
        return especieRepository.findAll();
    }
    @GetMapping("/{especieId}")
    public ResponseEntity<Especie> buscar(@PathVariable Long especieId){
        Optional<Especie> especie = especieRepository.findById(especieId);
        if (especie.isPresent()){
            return ResponseEntity.ok(especie.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{especieId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity <Especie> adicionar (@RequestBody Especie especie){
        especie = especieService.salvar(especie);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{especieId}")
    public ResponseEntity<Especie> atualizar (@PathVariable Long especieId, @RequestBody Especie especie){
        Optional<Especie> especieAtual = especieRepository.findById(especieId);
        if (especieAtual.isPresent()){
            BeanUtils.copyProperties(especie, especieAtual, "id");

            Especie especieSalva = especieService.salvar(especieAtual.get());
            return ResponseEntity.ok(especieSalva);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{especieId}")
    public  ResponseEntity<Especie> remover (Long especieId){
        try {
            especieService.excluir(especieId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
