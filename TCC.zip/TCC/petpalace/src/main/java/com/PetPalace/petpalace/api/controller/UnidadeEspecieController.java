package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Raca;
import com.PetPalace.petpalace.domain.model.Unidade;
import com.PetPalace.petpalace.domain.model.UnidadeEspecie;
import com.PetPalace.petpalace.domain.repository.UnidadeEspecieRepository;
import com.PetPalace.petpalace.domain.service.UnidadeEspecieService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/unidadeEspecies")
public class UnidadeEspecieController {

    @Autowired
    private UnidadeEspecieRepository unidadeEspecieRepository;
    @Autowired
    private UnidadeEspecieService unidadeEspecieService;

    @GetMapping
    public List<UnidadeEspecie> listar(){
        return unidadeEspecieRepository.findAll();
    }
    @GetMapping("/{unidadeEspecieId}")
    public ResponseEntity<UnidadeEspecie> buscar(@PathVariable Long unidadeEspecieId){
        Optional<UnidadeEspecie> unidadeEspecie = unidadeEspecieRepository.findById(unidadeEspecieId);
        if (unidadeEspecie.isPresent()){
            return ResponseEntity.ok(unidadeEspecie.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{unidadeEspecieId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity <UnidadeEspecie> adicionar (@RequestBody UnidadeEspecie unidadeEspecie){
        unidadeEspecie = unidadeEspecieService.salvar(unidadeEspecie);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{unidadeEspecieId}")
    public ResponseEntity<UnidadeEspecie> atualizar (@PathVariable Long unidadeEspecieId, @RequestBody UnidadeEspecie unidadeEspecie){
        Optional<UnidadeEspecie> unidadeEspecieAtual = unidadeEspecieRepository.findById(unidadeEspecieId);
        if (unidadeEspecieAtual.isPresent()){
            BeanUtils.copyProperties(unidadeEspecie, unidadeEspecieAtual, "id");

            UnidadeEspecie unidadeEspecieSalva = unidadeEspecieService.salvar(unidadeEspecieAtual.get());
            return ResponseEntity.ok(unidadeEspecieSalva);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{unidadeEspecieId}")
    public  ResponseEntity<UnidadeEspecie> remover (Long unidadeEspecieId){
        try {
            unidadeEspecieService.excluir(unidadeEspecieId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
