package com.PetPalace.petpalace.domain.service;

import com.PetPalace.petpalace.domain.model.FotoUnidade;
import com.PetPalace.petpalace.domain.model.Unidade;
import com.PetPalace.petpalace.domain.repository.FotoUnidadeRepository;
import com.PetPalace.petpalace.domain.repository.UnidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class UnidadeService {

    @Autowired
    private UnidadeRepository unidadeRepository;

    @Autowired
    private FotoUnidadeRepository fotoRepository;

    public Unidade salvarComFotos(Unidade unidade, List<MultipartFile> fotos) {

        Unidade salva = unidadeRepository.save(unidade);

        if (fotos != null) {
            List<FotoUnidade> listaFotos = new ArrayList<>();

            for (MultipartFile foto : fotos) {
                try {
                    FotoUnidade f = new FotoUnidade();
                    f.setNomeArquivo(foto.getOriginalFilename());
                    f.setContentType(foto.getContentType());
                    f.setTamanho(foto.getSize());
                    f.setDados(foto.getBytes());
                    f.setUnidade(salva);
                    listaFotos.add(f);

                } catch (IOException e) {
                    throw new RuntimeException("Erro ao processar foto", e);
                }
            }

            fotoRepository.saveAll(listaFotos);
            salva.setFotos(listaFotos);
        }

        return salva;
    }

    public Unidade salvar(Unidade unidade) {
        return unidadeRepository.save(unidade);
    }

    public void excluir(Long id) {
        unidadeRepository.deleteById(id);
    }
}
