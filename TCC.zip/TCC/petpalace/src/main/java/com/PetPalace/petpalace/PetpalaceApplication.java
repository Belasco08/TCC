package com.PetPalace.petpalace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetpalaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetpalaceApplication.class, args);
	}

}
