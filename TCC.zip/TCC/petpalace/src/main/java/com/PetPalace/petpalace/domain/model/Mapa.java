package com.PetPalace.petpalace.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;



@Table(name = "tb_mapa")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Data
public class Mapa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Campos que vão pro banco
    private Double latitude;
    private Double longitude;

    // Cliente HTTP
    private static final OkHttpClient client = new OkHttpClient();

    // Conversor JSON
    private static final ObjectMapper mapper = new ObjectMapper();

    // Busca latitude e longitude no Nominatim
    public static double[] getCoordenadas(String endereco) throws Exception {
        String url = "https://nominatim.openstreetmap.org/search?q="
                + endereco.replace(" ", "+")
                + "&format=json&limit=1";

        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (TCC Projeto)")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String json = response.body().string();
                JsonNode arr = mapper.readTree(json);

                if (arr.isArray() && arr.size() > 0) {
                    double lat = arr.get(0).get("lat").asDouble();
                    double lon = arr.get(0).get("lon").asDouble();

                    return new double[]{lat, lon};
                }
            }
        }
        return null;
    }

    // Fórmula de Haversine para calcular distância
    public static double calcularDistancia(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Raio da Terra em km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c; // Retorna em km
    }
}
