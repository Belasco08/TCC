package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.model.Anuncios;
import com.PetPalace.petpalace.domain.repository.AnunciosRepository;
import com.PetPalace.petpalace.domain.service.AnunciosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/anuncios")
public class AnunciosController {

    @Autowired
    private AnunciosRepository anunciosRepository;

    @Autowired
    private AnunciosService anunciosService;

    @GetMapping
    public List<Anuncios> listar() {
        return anunciosRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> adicionar(
            @RequestParam("titulo") String titulo,
            @RequestParam("descricao") String descricao,
            @RequestParam("preco_diaria") String precoDiaria,
            @RequestParam("fotos") MultipartFile fotos
    ) {
        try {
            // salvar imagem localmente
            String uploadDir = "uploads/";
            File dir = new File(uploadDir);
            if (!dir.exists()) dir.mkdirs();

            String fileName = System.currentTimeMillis() + "_" + fotos.getOriginalFilename();
            Path filePath = Paths.get(uploadDir, fileName);
            Files.copy(fotos.getInputStream(), filePath);

            // criar objeto
            Anuncios anuncio = new Anuncios();
            anuncio.setTitulo(titulo);
            anuncio.setDescricao(descricao);
            anuncio.setPreco_diaria(new java.math.BigDecimal(precoDiaria));
            anuncio.setFotos("/uploads/" + fileName);
            anuncio.setVagas_disponiveis(10);
            anuncio.setAvaliações("Novo");

            anunciosService.salvar(anuncio);

            return ResponseEntity.ok("Anúncio cadastrado com sucesso!");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erro ao salvar a imagem: " + e.getMessage());
        }
    }
}
