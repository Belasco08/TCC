package com.PetPalace.petpalace.domain.service;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Servico;
import com.PetPalace.petpalace.domain.repository.ServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicoService {

    @Autowired
    private ServicoRepository servicoRepository;

    public List<Servico> listar() {
        return servicoRepository.findAll();
    }

    public Servico salvar(Servico servico) {
        return servicoRepository.save(servico);
    }

    public Servico buscarOuFalhar(Long servicoId) {
        return servicoRepository.findById(servicoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Serviço de ID " + servicoId + " não encontrado."
                ));
    }

    public void excluir(Long servicoId) {
        try {
            if (!servicoRepository.existsById(servicoId)) {
                throw new EntidadeNaoEncontradaException(
                        "Serviço de ID " + servicoId + " não encontrado."
                );
            }

            servicoRepository.deleteById(servicoId);
            servicoRepository.flush();

        } catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(
                    "Serviço de ID " + servicoId + " não pode ser removido, pois está em uso."
            );
        }
    }
}
