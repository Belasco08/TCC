package com.PetPalace.petpalace.dto;

import lombok.Data;
import java.util.List;

@Data
public class UnidadeDTO {
    private Long id;
    private String nome;
    private String descricao;
    private Boolean aceitaGatos;
    private Boolean aceitaCaes;
    private String cidade;
    private String estado;
    private String telefone;
    private String email;
    private String enderecoTexto;
    private Double preco;
    private List<String> fotos; // URLs das fotos
}
