package com.PetPalace.petpalace.api.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/pagamentos")
public class MercadoPagoController {

    private final WebClient webClient;

    // Aqui armazenamos temporariamente o status dos pagamentos (em um projeto real, ficaria no banco)
    private final Map<String, String> statusPagamentos = new ConcurrentHashMap<>();

    public MercadoPagoController(@Value("${mercadopago.access.token}") String accessToken) {
        this.webClient = WebClient.builder()
                .baseUrl("https://api.mercadopago.com")
                .defaultHeader("Authorization", "Bearer " + accessToken)
                .build();
    }

    @PostMapping(value = "/criar", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<Map<String, Object>>> criarPagamento(@RequestBody Map<String, Object> dadosPagamento) {

        Map<String, Object> body = new HashMap<>();
        body.put("transaction_amount", dadosPagamento.get("valor"));
        body.put("description", dadosPagamento.get("descricao"));
        body.put("payment_method_id", "pix");
        body.put("payer", Map.of("email", dadosPagamento.get("email")));
        body.put("notification_url", "https://seu-dominio.com/pagamentos/webhook");

        return webClient.post()
                .uri("/v1/payments")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(new org.springframework.core.ParameterizedTypeReference<Map<String, Object>>() {})
                .map(response -> {
                    String idPagamento = String.valueOf(response.get("id"));
                    statusPagamentos.put(idPagamento, "pendente");
                    return ResponseEntity.ok(response);
                })
                .onErrorResume(e -> Mono.just(ResponseEntity.badRequest().body(Map.of("erro", e.getMessage()))));
    }

    @PostMapping("/webhook")
    public ResponseEntity<String> receberWebhook(@RequestBody Map<String, Object> payload) {
        System.out.println("📦 Webhook recebido:");
        System.out.println(payload);

        try {
            Map<String, Object> data = (Map<String, Object>) payload.get("data");
            String idPagamento = String.valueOf(data.get("id"));

            // Busca o pagamento atualizado
            webClient.get()
                    .uri("/v1/payments/" + idPagamento)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .subscribe(payment -> {
                        String status = String.valueOf(payment.get("status"));
                        statusPagamentos.put(idPagamento, status);
                        System.out.println("✅ Pagamento " + idPagamento + " atualizado para: " + status);
                    });

            return ResponseEntity.ok("Webhook processado");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Erro ao processar webhook");
        }
    }

    @GetMapping("/status/{idPagamento}")
    public ResponseEntity<Map<String, String>> verificarStatus(@PathVariable String idPagamento) {
        String status = statusPagamentos.getOrDefault(idPagamento, "desconhecido");
        return ResponseEntity.ok(Map.of("status", status));
    }
}
