package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.TipoUnidade;
import com.PetPalace.petpalace.domain.model.TipoUsuario;
import com.PetPalace.petpalace.domain.repository.TipoUsuarioRepository;
import com.PetPalace.petpalace.domain.service.TipoUsuarioService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tiposUsuario")
public class TipoUsuarioController {
    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;
    @Autowired
    private TipoUsuarioService tipoUsuarioService;

    @GetMapping
    public List<TipoUsuario> listar(){
        return tipoUsuarioRepository.findAll();
    }
    @GetMapping("/{tipoUsuarioId}")
    public ResponseEntity<TipoUsuario> buscar(@PathVariable Long tipoUsuarioId){
        Optional<TipoUsuario> tipoUsuario = tipoUsuarioRepository.findById(tipoUsuarioId);
        if (tipoUsuario.isPresent()){
            return ResponseEntity.ok(tipoUsuario.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{tipoUsuarioId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity <TipoUsuario> adicionar (@RequestBody TipoUsuario tipoUsuario){
        tipoUsuario = tipoUsuarioService.salvar(tipoUsuario);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{tipoUsuarioId}")
    public ResponseEntity<TipoUsuario> atualizar (@PathVariable Long tipoUsuarioId, @RequestBody TipoUsuario tipoUsuario){
        Optional<TipoUsuario> tipoUsuarioAtual = tipoUsuarioRepository.findById(tipoUsuarioId);
        if (tipoUsuarioAtual.isPresent()){
            BeanUtils.copyProperties(tipoUsuario, tipoUsuarioAtual, "id");

            TipoUsuario tipoUsuarioSalva = tipoUsuarioService.salvar(tipoUsuarioAtual.get());
            return ResponseEntity.ok(tipoUsuarioSalva);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{tipoUsuarioId}")
    public  ResponseEntity<TipoUsuario> remover (Long tipoUsuarioId){
        try {
            tipoUsuarioService.excluir(tipoUsuarioId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
