package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.model.FotoUnidade;
import com.PetPalace.petpalace.domain.model.Unidade;
import com.PetPalace.petpalace.domain.repository.FotoUnidadeRepository;
import com.PetPalace.petpalace.domain.repository.UnidadeRepository;
import com.PetPalace.petpalace.domain.service.UnidadeService;
import com.PetPalace.petpalace.dto.UnidadeDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/unidades")
public class UnidadeController {

    private static final String BASE_URL = "http://localhost:8080";

    @Autowired
    private UnidadeRepository unidadeRepository;

    @Autowired
    private FotoUnidadeRepository fotoRepository;

    @Autowired
    private UnidadeService unidadeService;

    private UnidadeDTO toDTO(Unidade u) {
        UnidadeDTO dto = new UnidadeDTO();
        BeanUtils.copyProperties(u, dto);

        dto.setAceitaGatos(u.getAceita_gatos());
        dto.setAceitaCaes(u.getAceita_caes());

        // GERAR URLs COMPLETAS DAS IMAGENS
        if (u.getFotos() != null) {
            dto.setFotos(
                    u.getFotos().stream()
                            .map(f -> BASE_URL + "/unidades/fotos/" + f.getId())
                            .collect(Collectors.toList())
            );
        }

        return dto;
    }

    // LISTAR TODAS AS UNIDADES
    @GetMapping
    public List<UnidadeDTO> listar() {
        return unidadeRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // BUSCAR POR ID
    @GetMapping("/{id}")
    public ResponseEntity<UnidadeDTO> buscar(@PathVariable Long id) {
        return unidadeRepository.findById(id)
                .map(u -> ResponseEntity.ok(toDTO(u)))
                .orElse(ResponseEntity.notFound().build());
    }

    // CADASTRAR UNIDADE + FOTOS
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<UnidadeDTO> cadastrar(
            @RequestPart("nome") String nome,
            @RequestPart("descricao") String descricao,
            @RequestPart("cidade") String cidade,
            @RequestPart("estado") String estado,
            @RequestPart("telefone") String telefone,
            @RequestPart("email") String email,
            @RequestPart("enderecoTexto") String enderecoTexto,
            @RequestPart("aceita_gatos") String aceitaGatos,
            @RequestPart("aceita_caes") String aceitaCaes,
            @RequestPart("preco") String preco,
            @RequestPart(value = "fotos", required = false) List<MultipartFile> fotos
    ) {

        Unidade u = new Unidade();

        u.setNome(nome);
        u.setDescricao(descricao);
        u.setCidade(cidade);
        u.setEstado(estado);
        u.setTelefone(telefone);
        u.setEmail(email);
        u.setEnderecoTexto(enderecoTexto);
        u.setPreco(Double.valueOf(preco));
        u.setAceita_gatos(Boolean.parseBoolean(aceitaGatos));
        u.setAceita_caes(Boolean.parseBoolean(aceitaCaes));

        Unidade salva = unidadeService.salvarComFotos(u, fotos);

        return ResponseEntity.status(HttpStatus.CREATED).body(toDTO(salva));
    }

    // VER FOTO DA UNIDADE
    @GetMapping("/fotos/{id}")
    public ResponseEntity<byte[]> verFoto(@PathVariable Long id) {
        Optional<FotoUnidade> foto = fotoRepository.findById(id);

        if (foto.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        FotoUnidade f = foto.get();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(f.getContentType()));
        headers.setContentLength(f.getTamanho());

        return new ResponseEntity<>(f.getDados(), headers, HttpStatus.OK);
    }

    // ATUALIZAR UNIDADE
    @PutMapping("/{id}")
    public ResponseEntity<UnidadeDTO> atualizar(@PathVariable Long id, @RequestBody Unidade dados) {
        Optional<Unidade> atual = unidadeRepository.findById(id);

        if (atual.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Unidade u = atual.get();
        BeanUtils.copyProperties(dados, u, "id", "fotos");

        Unidade salva = unidadeService.salvar(u);

        return ResponseEntity.ok(toDTO(salva));
    }

    // EXCLUIR UNIDADE
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable Long id) {
        unidadeService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
