package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Unidade;
import com.PetPalace.petpalace.domain.repository.UnidadeRepository;
import com.PetPalace.petpalace.domain.service.UnidadeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/unidades")
public class UnidadeController {
    @Autowired
    private UnidadeRepository unidadeRepository;

    @Autowired
    private UnidadeService unidadeService;

    @GetMapping
    public List<Unidade> listar(){
        return unidadeRepository.findAll();
    }

    @GetMapping("/{unidadeId}")
    public ResponseEntity<Unidade> buscar (@PathVariable Long unidadeId){
        Optional<Unidade> unidade = unidadeRepository.findById(unidadeId);
        if (unidade.isPresent()){
            return ResponseEntity.ok(unidade.get());
        }
        return ResponseEntity.notFound().build();
    }
    @PostMapping("/{unidadeId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Unidade> adicionar (@RequestBody Unidade unidade){
        unidade = unidadeService.salvar(unidade);
        return ResponseEntity.status(HttpStatus.CREATED).body(unidade);
    }

    @PutMapping("/{unidadeId}")
    public ResponseEntity<Unidade> atualizar (@PathVariable Long unidadeId, @RequestBody Unidade unidade){
        Optional<Unidade> unidadeAtual = unidadeRepository.findById(unidadeId);
        if (unidadeAtual.isPresent()){
            BeanUtils.copyProperties(unidade, unidadeAtual, "Id");
            Unidade unidadeSalva = unidadeService.salvar(unidadeAtual.get());
            return ResponseEntity.ok(unidade);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/{unidadeId}")
    public  ResponseEntity<Unidade> remover (Long unidadeId){
        try {
            unidadeService.excluir(unidadeId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
