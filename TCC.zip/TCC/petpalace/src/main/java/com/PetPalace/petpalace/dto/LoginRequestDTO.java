package com.PetPalace.petpalace.dto;

public record LoginRequestDTO (String email, String password){
}
