package com.PetPalace.petpalace.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "tb_foto_unidade")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class FotoUnidade {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nomeArquivo;
    private String contentType;
    private Long tamanho;

    @Lob
    @JsonIgnore // impede o base64 gigante de quebrar JSON
    private byte[] dados;

    @ManyToOne
    @JoinColumn(name = "unidade_id")
    @JsonIgnore      // ******* ESSA LINHA AQUI QUE CORRIGE O LOOP ********
    private Unidade unidade;
}
