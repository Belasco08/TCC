package com.PetPalace.petpalace.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(name = "tb_raca")
public class Raca {
    @EqualsAndHashCode.Include
    @Id
    private Long id;
    private String nome;

    @OneToOne
    @JoinColumn(name = "especie_id")
    private Especie especie;
}
