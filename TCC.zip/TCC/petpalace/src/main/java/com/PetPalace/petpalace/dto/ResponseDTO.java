package com.PetPalace.petpalace.dto;

public record ResponseDTO (String nome, String token){
}
