package com.PetPalace.petpalace.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(name = "tb_unidade")
public class Unidade {

    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String descricao;

    private Boolean aceita_gatos;
    private Boolean aceita_caes;

    private String cidade;
    private String estado;
    private String telefone;
    private String email;

    @Column(name = "endereco_texto")
    private String enderecoTexto;

    private Double preco;

    @OneToMany(
            mappedBy = "unidade",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.EAGER   // <-- ESSA É A ALTERAÇÃO
    )
    private List<FotoUnidade> fotos;

}
