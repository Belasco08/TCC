package com.PetPalace.petpalace.domain.model;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(name = "tb_unidade")
public class Unidade {
    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String descricao;
    private Boolean aceita_gatos;
    private Boolean aceita_caes;
    @OneToOne
    @JoinColumn(name = "mapa_id")
    private Mapa mapa;
    @OneToOne
    @JoinColumn(name = "tipoUnidade_id")
    private TipoUnidade tipoUnidade;
    @OneToOne
    @JoinColumn(name = "endereco_id")
    private Endereco endereco;
    @ManyToOne
    @JoinColumn(name = "servico_id")
    private Servico servico;
}
