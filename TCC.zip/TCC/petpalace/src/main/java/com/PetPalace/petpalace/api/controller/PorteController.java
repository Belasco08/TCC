package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Cidade;
import com.PetPalace.petpalace.domain.model.Porte;
import com.PetPalace.petpalace.domain.repository.CidadeRepository;
import com.PetPalace.petpalace.domain.repository.PorteRepository;
import com.PetPalace.petpalace.domain.service.CidadeService;
import com.PetPalace.petpalace.domain.service.PorteService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/portes")
public class PorteController {
    @Autowired
    private PorteRepository porteRepository;

    @Autowired
    private PorteService porteService;

    @GetMapping
    public List<Porte> listar(){
        return porteRepository.findAll();
    }

    @GetMapping("/{porteId}")
    public ResponseEntity<Porte> buscar (@PathVariable Long porteId){
        Optional<Porte> porte = porteRepository.findById(porteId);
        if (porte.isPresent()){
            return ResponseEntity.ok(porte.get());
        }
        return ResponseEntity.notFound().build();
    }
    @PostMapping("/{porteId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Porte> adicionar (@RequestBody Porte porte){
        porte = porteService.salvar(porte);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }


    @PutMapping("/{porteId}")
    public ResponseEntity<Porte> atualizar (@PathVariable Long porteId,@RequestBody Porte porte){
        Optional<Porte> porteAtual = porteRepository.findById(porteId);

        if (porteAtual.isPresent()){
            BeanUtils.copyProperties(porte ,porteAtual , "id");

            Porte porteSalva = porteService.salvar(porteAtual.get());

            return ResponseEntity.ok(porteSalva);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/{porteId}")
    public  ResponseEntity<Porte> remover (Long porteId){
        try {
            porteService.excluir(porteId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
