package com.PetPalace.petpalace.dto;

public record RegisterRequestDTO (String nome, String senha, String email){
}
