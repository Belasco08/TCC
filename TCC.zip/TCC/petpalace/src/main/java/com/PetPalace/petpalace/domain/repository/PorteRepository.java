package com.PetPalace.petpalace.domain.repository;

import com.PetPalace.petpalace.domain.model.Porte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PorteRepository extends JpaRepository<Porte, Long> {
}
