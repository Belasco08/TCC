package com.PetPalace.petpalace.domain.service;


import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.TipoUnidade;
import com.PetPalace.petpalace.domain.repository.TipoUnidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class TipoUnidadeService {
    @Autowired
    private TipoUnidadeRepository tipoUnidadeRepository;

    public TipoUnidade salvar (TipoUnidade tipoUnidade){
        return tipoUnidadeRepository.save(tipoUnidade);
    }

    public void excluir (Long id){
        try {
            tipoUnidadeRepository.deleteById(id);
        }
        catch (DataIntegrityViolationException e){
            throw new EntidadeEmUsoException(String.format("Tipo Animal ou codigo %d não pode ser encontrado, pois está em uso", id));
        }
        catch (EmptyResultDataAccessException e){
            throw new EntidadeNaoEncontradaException(String.format("Não existe cadastro de Tipo de Animais com codigo %d", id));
        }
    }
}
