package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Animal;
import com.PetPalace.petpalace.domain.model.Raca;
import com.PetPalace.petpalace.domain.repository.RacaRepository;
import com.PetPalace.petpalace.domain.service.RacaService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/racas")
public class RacaController {

    @Autowired
    private RacaRepository racaRepository;
    @Autowired
    private RacaService racaService;

    @GetMapping
    public List<Raca> listar(){
        return racaRepository.findAll();
    }
    @GetMapping("/{racaId}")
    public ResponseEntity<Raca> buscar(@PathVariable Long racaId){
        Optional<Raca> raca = racaRepository.findById(racaId);
        if (raca.isPresent()){
            return ResponseEntity.ok(raca.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{racaId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity <Raca> adicionar (@RequestBody Raca raca){
        raca = racaService.salvar(raca);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{racaId}")
    public ResponseEntity<Raca> atualizar (@PathVariable Long racaId, @RequestBody Raca raca){
        Optional<Raca> racaAtual = racaRepository.findById(racaId);
        if (racaAtual.isPresent()){
            BeanUtils.copyProperties(raca, racaAtual, "id");

            Raca racaSalva = racaService.salvar(racaAtual.get());
            return ResponseEntity.ok(racaSalva);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{racaId}")
    public  ResponseEntity<Raca> remover (Long racaId){
        try {
            racaService.excluir(racaId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
