package com.PetPalace.petpalace.domain.service;


import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Endereco;
import com.PetPalace.petpalace.domain.repository.EnderecoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;


@Service
public class EnderecoService {

    @Autowired
    private EnderecoRepository enderecoRepository;
    private final OkHttpClient client = new OkHttpClient();
    private final ObjectMapper mapper = new ObjectMapper();



    public Endereco salvar(Endereco endereco) throws Exception {
        // Monta endereço completo para consulta
        String enderecoCompleto = String.format("%s %s %s %s %s",
                endereco.getRua(),
                endereco.getNumero(),
                endereco.getBairro(),
                endereco.getCidade() != null ? endereco.getCidade().getNome() : "",
                endereco.getEstado() != null ? endereco.getEstado().getNome() : ""
        );

        // Busca coordenadas no Nominatim
        double[] coords = getCoordenadas(enderecoCompleto);
        if (coords != null) {
            endereco.setLatitude(BigDecimal.valueOf(coords[0]));
            endereco.setLongitude(BigDecimal.valueOf(coords[1]));
        }

        // Salva no banco já com lat/lon preenchidos
        return enderecoRepository.save(endereco);
    }

    private double[] getCoordenadas(String endereco) throws Exception {
        String url = "https://nominatim.openstreetmap.org/search?q="
                + endereco.replace(" ", "+")
                + "&format=json&limit=1";

        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (PetPalace TCC)")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String json = response.body().string();
                JsonNode arr = mapper.readTree(json);

                if (arr.isArray() && arr.size() > 0) {
                    double lat = arr.get(0).get("lat").asDouble();
                    double lon = arr.get(0).get("lon").asDouble();
                    return new double[]{lat, lon};
                }
            }
        }
        return null;
    }
    

    public void excluir (Long id){
        try {
            enderecoRepository.deleteById(id);
        }
        catch (DataIntegrityViolationException e){
            throw new EntidadeEmUsoException(String.format("Endereco ou codigo %d não pode ser encontrado, pois está em uso", id));
        }
        catch (EmptyResultDataAccessException e){
            throw new EntidadeNaoEncontradaException(String.format("Não existe cadastro de endereço com codigo %d", id));
        }
    }
}
