package com.PetPalace.petpalace.api.controller;

import com.PetPalace.petpalace.domain.exception.EntidadeEmUsoException;
import com.PetPalace.petpalace.domain.exception.EntidadeNaoEncontradaException;
import com.PetPalace.petpalace.domain.model.Animal;
import com.PetPalace.petpalace.domain.model.TipoUnidade;
import com.PetPalace.petpalace.domain.repository.TipoUnidadeRepository;
import com.PetPalace.petpalace.domain.service.TipoUnidadeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tipoUnidades")
public class TipoUnidadeControlller {
    @Autowired
    private TipoUnidadeRepository tipoUnidadeRepository;
    @Autowired
    private TipoUnidadeService tipoUnidadeService;

    @GetMapping
    public List<TipoUnidade> listar(){
        return tipoUnidadeRepository.findAll();
    }
    @GetMapping("/{tipoUnidadeId}")
    public ResponseEntity<TipoUnidade> buscar(@PathVariable Long tipoUnidadeId){
        Optional<TipoUnidade> tipoUnidade = tipoUnidadeRepository.findById(tipoUnidadeId);
        if (tipoUnidade.isPresent()){
            return ResponseEntity.ok(tipoUnidade.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{tipoUnidadeId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity <TipoUnidade> adicionar (@RequestBody TipoUnidade tipoUnidade){
        tipoUnidade = tipoUnidadeService.salvar(tipoUnidade);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{tipoUnidadeId}")
    public ResponseEntity<TipoUnidade> atualizar (@PathVariable Long tipoUnidadeId, @RequestBody TipoUnidade tipoUnidade){
        Optional<TipoUnidade> tipoUnidadeAtual = tipoUnidadeRepository.findById(tipoUnidadeId);
        if (tipoUnidadeAtual.isPresent()){
            BeanUtils.copyProperties(tipoUnidade, tipoUnidadeAtual, "id");

            TipoUnidade tipoUnidadeSalva = tipoUnidadeService.salvar(tipoUnidadeAtual.get());
            return ResponseEntity.ok(tipoUnidadeSalva);
        }
        {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{tipoUnidadeId}")
    public  ResponseEntity<TipoUnidade> remover (Long tipoUnidadeId){
        try {
            tipoUnidadeService.excluir(tipoUnidadeId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e){
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
