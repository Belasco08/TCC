package com.PetPalace.petpalace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetpalaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
